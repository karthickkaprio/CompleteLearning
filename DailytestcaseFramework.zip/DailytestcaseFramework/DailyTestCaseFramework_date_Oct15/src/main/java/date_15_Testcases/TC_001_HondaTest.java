package date_15_Testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import date_15_2Base.ProjectSpecificMethods;
import date_15_pages.HondaPage;

public class TC_001_HondaTest extends ProjectSpecificMethods{
	
	@BeforeTest
	public void SetValues() {
		TestCaseName="HondaPageActivity";
		Description="checking the displacement for two bikes";
		Author="Karthick";
		Category="smoke";
	}
	@Test
   public void runHonda() throws InterruptedException, IOException {
	   HondaPage hp=new HondaPage(driver,node,test);
	   hp.flashClick()
	   .firstScooterClick()
	   .dioClick()
	   .specificationClick1()
	   .moveToEngine()
	   .getDioDisplacement()
	   .secondScooterClick()
	   .activaClick()
	   .specificationClick2()
	   .moveToEngine()
	   .getActivaDisplacement()
	   .compareDisplacement()
	   .faqClick()
	   .Activa125BSClick()
	   .vehiclePriceClick()
	   .dropDownBike()
	   .submitClick()
	   .text2Click()
	   .dropdownState()
	   .dropdownCity()
	   .searchClick()
	   .printAllTheVehicleValues();
	   
	   
	   
	   
   }
}
