package date_15_pages;

import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import date_15_2Base.ProjectSpecificMethods;

public class SpecificationsPage extends ProjectSpecificMethods{
	
	public SpecificationsPage(RemoteWebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(how=How.XPATH,using="(//ul[@class='specifications']//a)[2]")
	public WebElement engine;
	
	@FindBy(how=How.XPATH,using="(//div[@class='engine part-2 axx']//span)[5]")
	public WebElement Diodisp;
	
	@FindBy(how=How.XPATH,using="(//div[@id='nivel-1']//a)[2]")
	public WebElement scooter2;
	
	@FindBy(how=How.XPATH,using="(//div[@id='scooter']//a/img)[2]")
	private WebElement activa;
	public SpecificationsPage moveToEngine() throws InterruptedException {
		mouseHover(engine);
		return this;
	}
    public SpecificationsPage getDioDisplacement() throws InterruptedException {
    	getTextDio(Diodisp);
    	return this;
    }
    public SpecificationsPage secondScooterClick() throws InterruptedException, IOException {
    	click(scooter2);
    	return this;
    }
    public Activa6GPage activaClick() throws InterruptedException, IOException {
    	click(activa);
    	return new Activa6GPage(driver);
    }
}
