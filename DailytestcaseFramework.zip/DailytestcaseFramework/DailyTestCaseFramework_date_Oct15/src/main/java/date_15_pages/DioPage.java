package date_15_pages;

import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import date_15_2Base.ProjectSpecificMethods;

public class DioPage extends ProjectSpecificMethods {
	
	public DioPage(RemoteWebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(how=How.XPATH,using="(//div[@id='accordion-1']//a)[4]")
	public WebElement specific1;
	
	public SpecificationsPage specificationClick1() throws InterruptedException, IOException {
		click(specific1);
		return new SpecificationsPage(driver);
	}
}
