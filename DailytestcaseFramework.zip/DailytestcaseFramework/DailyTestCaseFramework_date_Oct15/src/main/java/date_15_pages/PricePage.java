package date_15_pages;

import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import date_15_2Base.ProjectSpecificMethods;

public class PricePage extends ProjectSpecificMethods {
	
	public PricePage(RemoteWebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(how=How.XPATH,using="//select[@id='StateID']")
	public WebElement state;
	
	@FindBy(how=How.XPATH,using="//select[@id='CityID']")
	public WebElement city;
	
	@FindBy(how=How.XPATH,using="(//button[@type='button'])[2]")
	public WebElement search;
	
	@FindBy(how=How.XPATH,using="//table[@id='gvshow']")
	public WebElement tb;
	
	public PricePage dropdownState() throws InterruptedException, IOException {
		dropDown2(state);
		return this;
	}
	public PricePage dropdownCity() throws InterruptedException, IOException {
		dropDown3(city);
		return this;
	}
	public PricePage searchClick() throws InterruptedException, IOException {
		click(search);
		return this;
	}
	public PricePage printAllTheVehicleValues() {
		print(tb);
		return this;
	}
}
