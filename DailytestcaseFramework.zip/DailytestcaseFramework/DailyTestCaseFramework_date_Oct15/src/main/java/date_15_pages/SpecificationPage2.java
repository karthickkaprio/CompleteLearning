package date_15_pages;

import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import date_15_2Base.ProjectSpecificMethods;

public class SpecificationPage2 extends ProjectSpecificMethods {
	
	public SpecificationPage2(RemoteWebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(how=How.XPATH,using="(//ul[@class='specifications']//a)[2]")
	public WebElement engine1;
	
	@FindBy(how=How.XPATH,using="(//div[@class='engine part-2 axx']//span)[5]")
	public WebElement Activadisp;
	
	@FindBy(how=How.XPATH,using="(//ul[@class='nav navbar-nav']/li/a)[10]")
	public WebElement faq;
	
	public SpecificationPage2 moveToEngine() throws InterruptedException {
		mouseHover(engine1);
		return this;
	}
	public SpecificationPage2 getActivaDisplacement() throws InterruptedException {
		getTextActiva(Activadisp);
		return this;
	}
    public SpecificationPage2 compareDisplacement() throws InterruptedException {
    	compare(val1,val2);
    	return this;
    }
    public FaqPage faqClick() throws InterruptedException, IOException {
    	click(faq);
    	return new FaqPage(driver);
    }
}
