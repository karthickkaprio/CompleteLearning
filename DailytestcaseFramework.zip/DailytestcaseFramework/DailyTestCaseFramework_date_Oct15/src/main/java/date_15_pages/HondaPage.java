package date_15_pages;

import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;

import date_15_2Base.ProjectSpecificMethods;

public class HondaPage extends ProjectSpecificMethods {
	
	public HondaPage(RemoteWebDriver driver, ExtentTest node, ExtentTest test) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(how=How.XPATH,using="(//button[@type='button'])[2]")
	public WebElement Notificationclose;
	
	@FindBy(how=How.XPATH,using="(//div[@id='nivel-1']//a)[2]")
	public WebElement scooter1;
	
	@FindBy(how=How.XPATH,using="(//div[@id='scooter']//a/img)[1]")
	public WebElement dio;
	
	public HondaPage flashClick() throws InterruptedException, IOException {
	click(Notificationclose);
	return this;
	}
    public HondaPage firstScooterClick() throws InterruptedException, IOException {
    click(scooter1);
    return this;
    }
    public DioPage dioClick() throws InterruptedException, IOException {
    click(dio);
    return new DioPage(driver);
    }
}
