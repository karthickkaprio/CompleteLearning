package date_15_pages;

import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import date_15_2Base.ProjectSpecificMethods;

public class FaqPage extends ProjectSpecificMethods {
	
	public FaqPage(RemoteWebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(how=How.XPATH,using="((//div[@id='style-3']/div)[2]/a)[11]")
	public WebElement ActivaBS; 
	//javascriptexecutor use paniruken pathuko
	public BrowseByProductPage Activa125BSClick() throws InterruptedException, IOException{
		javaclick(ActivaBS);
		return new BrowseByProductPage(driver);
		
	}

}
