package date_15_pages;

import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import date_15_2Base.ProjectSpecificMethods;

public class BrowseByProductPage extends ProjectSpecificMethods {
	
	public BrowseByProductPage(RemoteWebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(how=How.XPATH,using="//li[@id='li6']/a")
	public WebElement vehicleprice; 
	
	@FindBy(how=How.XPATH,using="(//select[@name='ModelID'])[6]")
	public WebElement dropdown1;
	
	@FindBy(how=How.XPATH,using="//button[@id='submit6']")
	public WebElement button;
	
	@FindBy(how=How.XPATH,using="(//a[@target='_blank'])[11]")
	public WebElement text2;
	//javascriptececutor use paniruken pathuko
	public BrowseByProductPage vehiclePriceClick() throws InterruptedException, IOException {
		javaclick(vehicleprice);
		return this;
	}
	public BrowseByProductPage dropDownBike() throws InterruptedException, IOException {
		dropDown1(dropdown1);
		return this;
	}
    public BrowseByProductPage submitClick() throws InterruptedException, IOException {
    	click(button);
    	return this;
    }
    public PricePage text2Click() throws InterruptedException, IOException {
    	windowclick(text2);
    	return new PricePage(driver);
    }
}
