package date_15_pages;

import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import date_15_2Base.ProjectSpecificMethods;

public class Activa6GPage extends ProjectSpecificMethods {
	
	public Activa6GPage(RemoteWebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(how=How.XPATH,using="(//div[@id='accordion-1']//a)[4]")
	public WebElement specific2;
    
	public SpecificationPage2 specificationClick2() throws InterruptedException, IOException {
    	click(specific2);
    	return new SpecificationPage2(driver);
    }
}
