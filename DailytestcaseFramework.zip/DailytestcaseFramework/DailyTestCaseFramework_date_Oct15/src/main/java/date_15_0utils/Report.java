package date_15_0utils;

import java.io.IOException;

import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public abstract class Report {
	public static ExtentHtmlReporter reporter;
	public static ExtentReports extent;
	public static ExtentTest test,node;
	public static String TestCaseName,Description,Author,Category;
	
	public RemoteWebDriver driver;
	
	@BeforeSuite
	public void startReport() {
    //physical setup where to store
	reporter=new ExtentHtmlReporter("./ExtentReport/result.html");
	//maintain history in report
	reporter.setAppendExisting(true);
	//actual report with values
	extent=new ExtentReports();
	//to attach the report data in the physical report
	extent.attachReporter(reporter);
	}		
   
	@BeforeClass
	public void testCase() {
    //create dynamic testcasename and description and author and category
	test=extent.createTest(TestCaseName, Description);
	test.assignAuthor(Author);
	test.assignCategory(Category);
	}
	
	public abstract long takesnap();
	
	public void reportStep(String mess,String status ) throws IOException {
	
	//MediaEntityModelProvider img;
	
	long takesnap=100000L;
	takesnap=takesnap();
    if(status.equalsIgnoreCase("pass")) {
		node.pass(mess, MediaEntityBuilder.createScreenCaptureFromPath("./../ExtentReport/images/"+takesnap+".png").build());	
	}
	else if(status.equalsIgnoreCase("fail")) {
		node.fail(mess, MediaEntityBuilder.createScreenCaptureFromPath("./../ExtentReport/images/"+takesnap+".png").build());
	}
	}
	
	@AfterSuite
	public void endReport() {
	//mandatory to generate report
	extent.flush();
	}
	
}
