package date_15_1Base;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import date_15_0utils.Report;

public class Orgin extends Report {
	
	public WebDriverWait wait;
	public static String Diodisplacement,Activadisplacement,parentwindow,childwindow;
	public  static long val1,val2;
	
	public void chooseBrowser(String brow,String url) throws IOException {
		
			if(brow.equalsIgnoreCase("chrome")){
		    System.setProperty("webdriver.chrome.driver", "./driver/chromedriver.exe");
		    driver=new ChromeDriver();
		   
	       }
		    else if(brow.equalsIgnoreCase("firefox")) {
		    System.setProperty("webdriver.gecko.driver", "./driver/geckodriver_32 bit.exe");
		    driver=new FirefoxDriver();
		   }
		driver.get(url);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		}
      
	
	public void click(WebElement ele) throws InterruptedException, IOException {
		String text="";
	  try {
		  wait=new WebDriverWait(driver,60);
	      wait.until(ExpectedConditions.elementToBeClickable(ele));
		  text=ele.getText();
	      ele.click();
	      Thread.sleep(5000);
	      reportStep("The"+" "+text+" clicked successfully","pass");
	  }catch(Exception e) {
		  reportStep("The"+" "+text+" not clicked successfully","fail");
		  //throw new RuntimeException();
	  }
	}
	public void javaclick(WebElement ele) throws InterruptedException, IOException {
		String text="";
		   try{
			   wait=new WebDriverWait(driver,60);
		       wait.until(ExpectedConditions.elementToBeClickable(ele));
		       text=ele.getText();
		       JavascriptExecutor executor=(JavascriptExecutor)driver;
		       executor.executeScript("arguments[0].click();", ele);
		       Thread.sleep(10000);
		       reportStep("The"+" "+text+" clicked successfully","pass");
		   }catch(Exception e) {
			   reportStep("The"+" "+text+" not clicked successfully","fail");
			  // throw new RuntimeException();
		   }
    }
    public void mouseHover(WebElement ele) throws InterruptedException {
      wait=new WebDriverWait(driver,60);
      wait.until(ExpectedConditions.visibilityOfAllElements(ele));
      Actions builder=new Actions(driver);
      builder.moveToElement(ele).perform();
     
    }
    public void getTextDio(WebElement ele) throws InterruptedException {
      String disp=ele.getText();
      Diodisplacement=disp.replaceAll("\\D", "");
      Thread.sleep(3000);
      val1=Integer.parseInt(Diodisplacement);
      System.out.println("Diodisplacement="+Diodisplacement);
      
      }
    public void getTextActiva(WebElement ele) throws InterruptedException {
        String disp=ele.getText();
        Activadisplacement=disp.replaceAll("\\D", "");
        Thread.sleep(3000);
        val2=Integer.parseInt(Activadisplacement);
        System.out.println("Activadisplacement="+Activadisplacement);
        
        }
    public void compare(long val1,long val2) throws InterruptedException {
    	
    	if(val1==val2) {
    		System.out.println("Both dio and Activa having same displacement");
    		Thread.sleep(2000);
    		}
    	else if(val1>val2) {
    		System.out.println("Dio has Higher displacement");
    		Thread.sleep(2000);
    	}
    	else {
    		System.out.println("Activa has higher displacement");
    		Thread.sleep(2000);
    	}
    	
    }
    public void dropDown1(WebElement ele) throws InterruptedException, IOException {
    	
    	try{
    		wait=new WebDriverWait(driver,60);
    	    wait.until(ExpectedConditions.visibilityOfAllElements(ele));
    	    
    	    Select st=new Select(ele);
    	    st.selectByValue("31");
    	    Thread.sleep(3000);
    	    reportStep("The dropdown1 value 31 selected successfully","pass");
    	}catch(Exception e) {
    		reportStep("The dropdown1 value 31 not selected successfully","fail");
    		//throw new RuntimeException();
    	}
    	
    }
    public void windowclick(WebElement ele) throws InterruptedException, IOException {
    	String text="";
        try{
        	wait=new WebDriverWait(driver,60);
            wait.until(ExpectedConditions.elementToBeClickable(ele));
            text=ele.getText();
 	        JavascriptExecutor executor=(JavascriptExecutor)driver;
	        executor.executeScript("arguments[0].click();", ele);
	        Thread.sleep(2000);
	        Set<String> window=driver.getWindowHandles();
    	    List<String> win=new ArrayList<String>(window);
    	    parentwindow=win.get(0);
    	    childwindow=win.get(1);
    	    driver.switchTo().window(childwindow);
    	    reportStep("The"+" "+text+" clicked succsessfully","pass");
        }catch(Exception e) {
        	reportStep("The"+" "+text+" not clicked successfully","fail");
        	//throw new RuntimeException();
        }
  
    }
    public void dropDown2(WebElement ele) throws InterruptedException, IOException {
    
    	try{
    		wait=new WebDriverWait(driver,60);
    	    wait.until(ExpectedConditions.visibilityOfAllElements(ele));
            Thread.sleep(10000);
            Select st=new Select(ele);
    	    st.selectByValue("28");
    	    Thread.sleep(2000);
    	    reportStep("The dropdown2 value 28 selected successfully","pass");
    	}catch(Exception e) {
    		reportStep("The dropdown2 value 28 not selected successfully","fail");
    		//throw new RuntimeException();
    	}
    	
    }
    public void dropDown3(WebElement ele) throws InterruptedException, IOException {
    
    	try{
    		wait=new WebDriverWait(driver,60);
    	    wait.until(ExpectedConditions.visibilityOfAllElements(ele));
    	  
    	    Select st=new Select(ele);
    	    st.selectByVisibleText("Chennai");
    	    reportStep("The dropdown3 value chennai selected successfully","pass");
    	}catch(Exception e) {
    		reportStep("The dropdown3 value chennai not selected successfully","fail");
    	   // throw new RuntimeException();
    	}
    }
    public void print(WebElement ele) {
        List<WebElement> column1=ele.findElements(By.tagName("td"));
 	    for(int i=1;i<=column1.size()-1;i++) {
        String firstcolumn=column1.get(i).getText();
        String secondcolumn=column1.get(i+1).getText();
        System.out.println(firstcolumn+"  "+secondcolumn);
        i++;
    }
 	
    }

	@Override
	public long takesnap() {
		long number=(long) (Math.floor(Math.random()*900000000L)+1000000L);
		try{
			FileUtils.copyFile(driver.getScreenshotAs(OutputType.FILE),
					new File("./ExtentReport/images/"+number+".png"));
		}catch(WebDriverException e) {
			System.out.println("the brower has been closed");
		}catch(IOException e) {
			System.out.println("the snapshot could not be taken");
		}
			return number;
	}   
}
