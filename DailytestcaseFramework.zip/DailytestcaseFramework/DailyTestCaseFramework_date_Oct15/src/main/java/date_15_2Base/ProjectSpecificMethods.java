package date_15_2Base;

import java.io.IOException;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import date_15_1Base.Orgin;

public class ProjectSpecificMethods extends Orgin {
	
	@BeforeMethod
	public void startBrow() throws IOException {
		chooseBrowser("firefox","https://www.honda2wheelersindia.com/");
		node=test.createNode(TestCaseName);
	}
	

	@AfterMethod
	public void closeBrowser() throws InterruptedException {
			driver.close();
			driver.switchTo().window(parentwindow);
			Thread.sleep(2000);
			driver.close();
		}
	
	
}