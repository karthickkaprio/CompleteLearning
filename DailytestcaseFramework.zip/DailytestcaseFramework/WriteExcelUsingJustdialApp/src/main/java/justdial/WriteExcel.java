package justdial;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class WriteExcel {

	public static void main(String[] args) throws IOException {
	File src =new File("./ExcelWrite/justdial.xlsx");
	FileInputStream fis=new FileInputStream(src);
	
	XSSFWorkbook wb=new XSSFWorkbook(fis);
    XSSFSheet sheet=wb.getSheet("sheet1");
    sheet.getRow(1).createCell(0).setCellValue("greenbox");
    sheet.getRow(1).createCell(1).setCellValue("votes");
    
    FileOutputStream fos=new FileOutputStream(src);
    wb.write(fos);
    wb.close();
	}

}
