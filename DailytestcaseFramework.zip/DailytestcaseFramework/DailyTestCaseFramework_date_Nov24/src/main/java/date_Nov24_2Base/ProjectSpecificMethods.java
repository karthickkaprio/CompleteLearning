package date_Nov24_2Base;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import date_Nov24_1Base.Orgin;

public class ProjectSpecificMethods extends Orgin {

@BeforeMethod
public void StartBrowser() {
	chooseBrowser("edge","https://www.redbus.in/");
	node=test.createNode(TestName);
}
@AfterMethod
public void endBrowser() {
	driver.close();
}
}
