package date_Nov24_0utils;

import java.io.IOException;

import org.openqa.selenium.WebDriverException;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public abstract class Report {
public static ExtentHtmlReporter reporter;
public static ExtentReports extent;
public static ExtentTest test,node;
public String TestName,TestDescription,Author,Category;

@BeforeSuite
public void startReport() {
reporter=new ExtentHtmlReporter("./ExtentReport/result.html");
reporter.setAppendExisting(true);
extent=new ExtentReports();
extent.attachReporter(reporter);
}

@BeforeClass
public void testcase() {
 test=extent.createTest(TestName, TestDescription);
 test.assignAuthor(Author);
 test.assignCategory(Category);
}
public abstract long redbus() throws WebDriverException, IOException;

public void reportStep(String des,String result) throws IOException {
	
	long redbus=redbus();
	if(result.equalsIgnoreCase("pass")) {
		node.pass(des, MediaEntityBuilder.createScreenCaptureFromPath("./../ExtentReport/redbus/"+redbus+".jpg").build());
	}else if(result.equalsIgnoreCase("fail")){
		node.fail(des, MediaEntityBuilder.createScreenCaptureFromPath("./../ExtentReport/redbus/"+redbus+".jpg").build());
	}
	}
@AfterSuite
public void endReport() {
	extent.flush();
}
}

