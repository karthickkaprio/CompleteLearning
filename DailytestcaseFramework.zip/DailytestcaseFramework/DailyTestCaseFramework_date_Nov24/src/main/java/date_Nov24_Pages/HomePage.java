package date_Nov24_Pages;

import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;

import date_Nov24_2Base.ProjectSpecificMethods;

public class HomePage extends ProjectSpecificMethods {

public HomePage(RemoteWebDriver driver,ExtentTest test,ExtentTest node) {
	this.driver=driver;
	PageFactory.initElements(driver, this);
}
@FindBy(how=How.XPATH,using="//input[@id='dest']")
WebElement to;

@FindBy(how=How.XPATH,using="//input[@id='src']")
WebElement from;

@FindBy(how=How.XPATH,using="//ul[@class='autoFill']/li")
WebElement firstplace;

@FindBy(how=How.XPATH,using="//div[@id='rb-calendar_onward_cal']/table")
WebElement tab1;

@FindBy(how=How.XPATH,using="//button[@id='search_btn']")
WebElement search;

public HomePage enterTo() throws InterruptedException, IOException {
	enter(to);
	return this;
}
public HomePage enterfrom() throws InterruptedException, IOException {
	enter1(from,firstplace,to);
	return this;
}
public HomePage chooseDate() throws IOException, InterruptedException {
	selectDate(tab1);
	return this;
}
public SearchBusesPage clickSearch() throws IOException {
	click(search);
	return new SearchBusesPage(driver);
}

}
