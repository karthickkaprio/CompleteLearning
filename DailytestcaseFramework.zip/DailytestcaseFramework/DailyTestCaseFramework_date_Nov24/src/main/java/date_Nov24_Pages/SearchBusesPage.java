package date_Nov24_Pages;

import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;

import date_Nov24_2Base.ProjectSpecificMethods;

public class SearchBusesPage extends ProjectSpecificMethods {
	
public SearchBusesPage(RemoteWebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

@FindBy(how=How.XPATH,using="(//div[@class='overlay-container']/div)[1]")
WebElement flash;

@FindBy(how=How.XPATH,using="//span[@class='f-bold busFound']")
WebElement num;

@FindBy(how=How.XPATH,using="//label[@for='bt_SLEEPER']")
WebElement sleeper;

@FindBy(how=How.XPATH,using="(//div[@class='seat-left m-top-30'])[1]")
WebElement seats;

@FindBy(how=How.XPATH,using="(//div[@class='seat-fare ']//span)[1]")
WebElement price;

@FindBy(how=How.XPATH,using="(//div[text()='View Seats'])[1]")
WebElement view;

@FindBy(how=How.XPATH,using="(//span[text()='Bus Photos'])[1]")
WebElement busphoto;

@FindBy(how=How.XPATH,using="(//button[@type='button'])[2]")
WebElement button;

public SearchBusesPage clickFlash() throws IOException {
    click(flash);
	return this;
    }
public SearchBusesPage busCount() {
	count(num);
	return this;
    }
public SearchBusesPage clickSleeper() throws IOException {
	click(sleeper);
	return this;
}
public SearchBusesPage seatsCount() {
	seats(seats);
	return this;
}
public SearchBusesPage price() {
	charge(price);
	return this;
}
public SearchBusesPage viewseats() throws InterruptedException, IOException {
	mousehover(view);
	return this;
}
public SearchBusesPage busImage() throws IOException {
	click(busphoto);
	return this;
}
public SearchBusesPage takeScreenShot() throws IOException, InterruptedException {
	take(button);
	return this;
}
}
