package date_Nov24_Testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import date_Nov24_2Base.ProjectSpecificMethods;
import date_Nov24_Pages.HomePage;

public class TC_001_RedbusTest extends ProjectSpecificMethods{
	@BeforeTest
	public void SetValues() {
		TestName="SearchBuses";
		TestDescription="checking the available seats and prices";
		Author="Karthick";
		Category="smoke";
	}
	@Test
	public void runRedBus() throws InterruptedException, IOException {
		HomePage hp=new HomePage(driver,test,node);
		hp.enterTo()
		.enterfrom()
		.chooseDate()
		.clickSearch()
		.clickFlash()
		.busCount()
		.clickSleeper()
		.seatsCount()
		.price()
		.viewseats()
		.busImage()
		.takeScreenShot();
	}

}
