package date_Nov24_1Base;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.time.Month;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import date_Nov24_0utils.Report;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Orgin extends Report{
public RemoteWebDriver driver;
public String conmon;
public void chooseBrowser(String brow,String url) {
	if(brow.equalsIgnoreCase("chrome")) {
		WebDriverManager.chromedriver().setup();
		ChromeOptions option=new ChromeOptions();
		option.addArguments("--disable-notifications");
		driver=new ChromeDriver(option);
		Capabilities cap=driver.getCapabilities();
		String browsername=cap.getBrowserName();
		System.out.println("browsername="+browsername);
		String version=cap.getVersion();
		System.out.println("version="+version);
	}
	else if(brow.equalsIgnoreCase("firefox")) {
		WebDriverManager.firefoxdriver().setup();
		FirefoxOptions option=new FirefoxOptions();
		option.setCapability("--disable-notifications", true);
		driver=new FirefoxDriver(option);
		Capabilities cap=driver.getCapabilities();
        String browsername=cap.getBrowserName();	
	    System.out.println("browsername="+browsername);
	    String version=cap.getVersion();
	    System.out.println("version="+version);
	}
	else if(brow.equalsIgnoreCase("edge")) {
		WebDriverManager.edgedriver().setup();
		EdgeOptions option=new EdgeOptions();
		option.setCapability("--disable-notifications", true);
		driver=new EdgeDriver(option);
		Capabilities cap=driver.getCapabilities();
		String browsername=cap.getBrowserName();
		System.out.println("browsername="+browsername);
		String version=cap.getVersion();
		System.out.println("version="+version);
	}
	driver.get(url);
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
}

public void callkey(WebElement ele) throws IOException {
	String val="";
try{
	val=ele.getText();
	WebDriverWait wait=new WebDriverWait(driver,20);
    wait.until(ExpectedConditions.elementToBeClickable(ele));
    ele.sendKeys(Keys.SHIFT,Keys.chord(Keys.TAB));
    
    Thread.sleep(1000);
    reportStep("The"+" "+val+" "+"clicked Successfully","pass");
}catch(Exception e) {
	reportStep("The"+" "+val+" "+"not clicked Successfully","fail");
}
}
public void callkey1(WebElement ele) throws IOException {
	String val="";
try{
	val=ele.getText();
	WebDriverWait wait=new WebDriverWait(driver,20);
    wait.until(ExpectedConditions.elementToBeClickable(ele));
    ele.sendKeys(Keys.CONTROL,Keys.chord(Keys.TAB));
    
    Thread.sleep(1000);
    reportStep("The"+" "+val+" "+"clicked Successfully","pass");
}catch(Exception e) {
	reportStep("The"+" "+val+" "+"not clicked Successfully","fail");
}
}
public void sel(WebElement ele) throws InterruptedException, IOException {
	String val="";
try{
	val=ele.getText();
	WebDriverWait wait=new WebDriverWait(driver,20);
	wait.until(ExpectedConditions.elementToBeClickable(ele));
    ele.click();
    Thread.sleep(1000);
    reportStep("The"+" "+val+" "+"not clicked Successfully","pass");
}catch(Exception e) {
	reportStep("The"+" "+val+" "+"selected Successfully","fail");
}
}
public void enter(WebElement ele) throws InterruptedException, IOException {
	String val="";
try{
	val=ele.getText();
	WebDriverWait wait=new WebDriverWait(driver,20);
    wait.until(ExpectedConditions.elementToBeClickable(ele));
    ele.click();
    ele.sendKeys("Bangalore");
    Thread.sleep(1000);
    callkey(ele);
    
    Thread.sleep(1000);
    reportStep("The"+" "+val+" "+"entered successfully","pass");
}catch(Exception e) {
	reportStep("The"+" "+val+" "+"not entered successfull","fail");
}
}
public void enter1(WebElement ele,WebElement fplace, WebElement to) throws InterruptedException, IOException {
   String val="";
try{
	val=ele.getText();
	WebDriverWait wait=new WebDriverWait(driver,20);
    wait.until(ExpectedConditions.elementToBeClickable(ele));
    ele.click();
    ele.sendKeys("Chennai");
    Thread.sleep(1000);
    sel(fplace);
    
    Thread.sleep(1000);
    callkey1(to);
    
    Thread.sleep(1000);
    sel(fplace);
    
    Thread.sleep(1000);
    reportStep("The"+" "+val+" "+"entered successfully","pass");
}catch(Exception e) {
	reportStep("The"+" "+val+" "+"not entered successfull","fail");
}
}
public void calldate() {
	String nm,nm1,firstlett,nm2;
	LocalDate date=LocalDate.now();
    Month currentmonth=date.getMonth();
    Month nextmonth=currentmonth.plus(1);
    nm=nextmonth.toString();
    nm1=nm.substring(0, 3);
    firstlett=nm1.substring(0,1);
    nm2=nm1.substring(1).toLowerCase();
    conmon=firstlett+nm2;
   
}
public void selectDate(WebElement ele) throws IOException, InterruptedException {
	 calldate();
	 List<WebElement> row=ele.findElements(By.tagName("tr"));
	 List<WebElement> column=ele.findElements(By.tagName("td"));
	 int i=1;
   try {
	do {
	String actualmonth=column.get(1).getText();
	String actual=actualmonth.replaceAll("\\d", "");
    System.out.println("actualmonth="+actualmonth);
    System.out.println("actual="+actual);
    if(actual.equals(conmon)) {
   	 System.out.println("yes month matches");
   	 break;
    }
    WebElement button=driver.findElementByXPath("//button[text()='>']");
    WebDriverWait wait=new WebDriverWait(driver,10);
    wait.until(ExpectedConditions.elementToBeClickable(button));
    button.click();
    i++;
    }while(i<=12);
	reportStep("The next button clicked Successfully","pass");
    }catch(IOException e) {
   	reportStep("The next button not clicked Successfull","fail");
    }catch(Exception e) {
    System.out.println("stale element exception");
    }
    try{
    	String firstdayofmonday=driver.findElementByXPath("(//th[text()='Mo']/following::td)[1]").getAttribute("class");
        System.out.println("firstdayofmonday="+firstdayofmonday);
        if(firstdayofmonday.contains("empty day")) {
   	    driver.findElementByXPath("(//th[text()='Mo']/following::td)[8]").click();
        }else {
   	    driver.findElementByXPath("(//th[text()='Mo']/following::td)[1]").click();
       }
       reportStep("The Date selected Successfully","pass");
       }catch(Exception e) {
       reportStep("The Date not selected Successfull","fail");
       }
    }
public void click(WebElement ele) throws IOException {
	String val="";
try{
	val=ele.getText();
	WebDriverWait wait=new WebDriverWait(driver,20);
	wait.until(ExpectedConditions.elementToBeClickable(ele));
	ele.click();
	reportStep("The"+" "+val+"clicked Successfully","pass");
	}catch(Exception e) {
	reportStep("The"+" "+val+"not clicked successfull","fail");	
	}
}
public void count(WebElement val) {
	//System.out.println("buscount="+val);
	String val1=val.getText();
	String count=val1.replaceAll("\\D", "");
	System.out.println("Buscount="+count);
}
public void seats(WebElement val) {
	String val1=val.getText();
	System.out.println("seatsCount="+val1);
}
public void charge(WebElement val) {
	String val1=val.getText();
	System.out.println("price="+val1);
}
public void mousehover(WebElement ele) throws InterruptedException, IOException {
	String val="";
try{
	val=ele.getText();
	JavascriptExecutor exe=(JavascriptExecutor)driver;
	exe.executeScript("arguments[0].scrollIntoView(true);",ele);
	Actions builder =new Actions(driver);
	builder.moveToElement(ele).perform();
    reportStep("The"+" "+val+" mousehovered successfully","pass");	
    }catch(Exception e) {
	reportStep("The"+" "+val+" not mousehoverd successfull","fail");	
	}
}
public void take(WebElement ele) throws IOException, InterruptedException {
    try{
     for(int j=1;j<=15;j++) {
     WebElement img=driver.findElementByXPath("(//img[@class='bus-image-new'])["+j+"]");
	 Actions builder1=new Actions(driver);
	 builder1.moveToElement(img).perform();
	 File src=driver.getScreenshotAs(OutputType.FILE);
	 File des=new File("./snaps/redbus/redbus"+j+".png");
	 FileUtils.copyFile(src, des);
	 Thread.sleep(2000);
	 click(ele);
     }
    }catch(Exception e) {
    	 System.out.println("no button present");
    	 System.out.println("no bus image found");
     }
}
public long redbus() throws WebDriverException, IOException {
long num=(long) Math.floor((Math.random()*90000000L)+10000000L);
try{
	FileUtils.copyFile(driver.getScreenshotAs(OutputType.FILE), new File("./ExtentReport/redbus/"+num+".jpg"));
}catch(Exception e) {
	System.out.println("screenshot could not be taken");
}
return num;
}
}

