package date_Nov25_Pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import date_Nov25_2Base.ProjectSpecificMethods;

public class ComputerGlassesPage extends ProjectSpecificMethods{
 public ComputerGlassesPage(RemoteWebDriver driver) {
	 this.driver=driver;
	 PageFactory.initElements(driver, this);
 }
	
@FindBy(how=How.XPATH,using="//span[@title='Round']")
WebElement round;

@FindBy(how=How.XPATH,using="//div[@class='show_count']")
WebElement result;

	 public ComputerGlassesPage round() throws InterruptedException {
	    	click1(round);
	    	return this;
	    }
     public ComputerGlassesPage confirmCount() throws InterruptedException {
    	 getText(result);
    	 return this;
     }
}
