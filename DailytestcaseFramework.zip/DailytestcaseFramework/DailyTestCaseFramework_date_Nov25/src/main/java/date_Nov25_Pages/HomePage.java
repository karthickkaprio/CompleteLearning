package date_Nov25_Pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import date_Nov25_2Base.ProjectSpecificMethods;

public class HomePage extends ProjectSpecificMethods {
	public HomePage(RemoteWebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

@FindBy(how=How.XPATH,using="//a[text()='Computer Glasses']")
WebElement computer;

@FindBy(how=How.XPATH,using="(//div[@class='gender_info'])[4]")
WebElement men;

@FindBy(how=How.XPATH,using="(//div[@class='category-menu_data category active'])[3]")
WebElement premium;

    public HomePage computerGlasses() {
		mousehover(computer);
		return this;
	}
    public HomePage men() {
    	mousehover(men);
    	return this;
    }
    public ComputerGlassesPage premiumRange() {
    	click(premium);
    	return new ComputerGlassesPage(driver);
    }
   
}
