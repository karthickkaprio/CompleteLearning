package date_Nov25_TestCase;

import org.testng.annotations.Test;

import date_Nov25_2Base.ProjectSpecificMethods;
import date_Nov25_Pages.HomePage;

public class TC_001_lenskartTest extends ProjectSpecificMethods{
	
	@Test
	public void runLenskart() throws InterruptedException {
		HomePage hp=new HomePage(driver);
		hp.computerGlasses()
		.men()
		.premiumRange()
		.round()
		.confirmCount();
		}
}
