package date_Nov25_2Base;

import org.testng.annotations.BeforeMethod;

import date_Nov25_1Base.Orgin;

public class ProjectSpecificMethods extends Orgin {
	
	@BeforeMethod
	public void startBrowser() {
		chooseBrow("Edge","https://www.lenskart.com/");
	}
	
	
    public void endbrowser() {
    	driver.close();
    }
}
